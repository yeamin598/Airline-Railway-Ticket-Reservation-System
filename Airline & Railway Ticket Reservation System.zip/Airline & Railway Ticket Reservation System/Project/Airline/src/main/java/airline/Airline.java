/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package airline;

/**
 *
 * @author Tamim Ahmed Titir
 */
public class Airline {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
